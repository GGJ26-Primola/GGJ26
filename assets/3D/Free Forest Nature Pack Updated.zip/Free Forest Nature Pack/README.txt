

~ Free Low Poly Trees & Forest Nature Pack for Godot / Unity / Unreal ~ 
UPDATED with more models!


by hooray4brains 
https://hooray4brains.itch.io/


Includes:
Low-poly trees (different kinds), rocks, bushes, mushrooms, grass and more. Stylized, flat colors. 
Game-ready .glb models for use in Godot, Unity, Unreal, etc.


License: 
Free for commercial and personal use.
Attribution appreciated, not required.
Do not resell or redistribute the raw files.


~ ~ ~

For even more models and gradient color variations, see the complete pack:
https://hooray4brains.itch.io/low-poly-forest-nature-pack